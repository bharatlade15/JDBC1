package com.jspiders.musicplayer.song;

public class Song {

	private int id;
	private String song_name;
	private String singer_name;
	private String movie_name;
	private double duration;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSong_name() {
		return song_name;
	}
	public void setSong_name(String song_name) {
		this.song_name = song_name;
	}
	public String getSinger_name() {
		return singer_name;
	}
	public void setSinger_name(String singer_name) {
		this.singer_name = singer_name;
	}
	public String getMovie_name() {
		return movie_name;
	}
	public void setMovie_name(String movie_name) {
		this.movie_name = movie_name;
	}
	public double getDuration() {
		return duration;
	}
	public void setDuration(double duration) {
		this.duration = duration;
	}
	
	@Override
	public String toString() {
		return "Song [id=" + id + ", song_name=" + song_name + ", singer_name=" + singer_name + ", movie_name="
				+ movie_name + ", duration=" + duration + "]";
	}
}
